plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    id ("kotlin-kapt")
    id("com.google.dagger.hilt.android")
    id("dagger.hilt.android.plugin")
}

android {
    namespace = "com.listingapp"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.listingapp"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    kotlinOptions {
        jvmTarget = "11"
    }
    buildFeatures {
        compose = true
    }
}

dependencies {

    // core libraries
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)

    // compose
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.ui)
    implementation(libs.androidx.ui.graphics)
    implementation(libs.androidx.ui.tooling.preview)
    implementation(libs.androidx.material3)

    // additional library
    implementation(libs.androidx.foundation)
    implementation(libs.compose.shimmer)
    implementation(libs.coil.compose)
    implementation(libs.coil.gif)
    implementation(libs.android.async.http)
    implementation("com.airbnb.android:lottie-compose:6.1.0")


    // navigation
    implementation(libs.androidx.navigation.compose)
    implementation(libs.androidx.navigation.ui.ktx)

    // location
    implementation(libs.play.services.location)

    //retrofit
    implementation (libs.retrofit)
    implementation (libs.converter.gson)

    //implementation("com.squareup.retrofit2:retrofit:2.11.0")
    //implementation("com.squareup.retrofit2:converter-gson:2.9.0")
    //implementation("com.jakewharton.retrofit:retrofit2-kotlin-coroutines-adapter:0.9.2")

    // Room Database
//    implementation(libs.androidx.room.runtime)
//    kapt(libs.androidx.room.compiler)
//    implementation(libs.androidx.room.ktx)
//
//    // hilt viewModel
//    implementation(libs.hilt.android)
//    kapt(libs.hilt.android.compiler)
//    implementation(libs.androidx.hilt.navigation.compose)

    //Hilt
    implementation("com.google.dagger:hilt-android:2.49")
    implementation(libs.volley)
    implementation(libs.androidx.paging.common.android)
    kapt("com.google.dagger:hilt-android-compiler:2.48")
    implementation("androidx.hilt:hilt-navigation-compose:1.2.0")

    //Room
    implementation("androidx.room:room-runtime:2.6.1")
    kapt("androidx.room:room-compiler:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")

    implementation (libs.androidx.paging.runtime)
    implementation ("androidx.room:room-paging:2.6.1")
    implementation ("androidx.paging:paging-compose:3.2.1") // For Jetpack Compose support

    debugImplementation(libs.androidx.ui.tooling)
}