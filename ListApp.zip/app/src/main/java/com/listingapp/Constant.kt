package com.listingapp

object Constant {
    val API_KEY = "e164fde22e382b3b3d0c7f19f4fc7431"
    val WEATHER_API = "https://api.openweathermap.org/data/2.5/weather?"
    val CITY_API = "https://api.openweathermap.org/geo/1.0/reverse?"
    val USER_API = "https://randomuser.me/api/?results=200"
    val ICON_API = "https://openweathermap.org/img/wn/"
}